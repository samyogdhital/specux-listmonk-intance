--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.13
-- Dumped by pg_dump version 13.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE listmonk;
--
-- Name: listmonk; Type: DATABASE; Schema: -; Owner: listmonk
--

CREATE DATABASE listmonk WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE listmonk OWNER TO listmonk;

\connect listmonk

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bounce_type; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.bounce_type AS ENUM (
    'soft',
    'hard',
    'complaint'
);


ALTER TYPE public.bounce_type OWNER TO listmonk;

--
-- Name: campaign_status; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.campaign_status AS ENUM (
    'draft',
    'running',
    'scheduled',
    'paused',
    'cancelled',
    'finished'
);


ALTER TYPE public.campaign_status OWNER TO listmonk;

--
-- Name: campaign_type; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.campaign_type AS ENUM (
    'regular',
    'optin'
);


ALTER TYPE public.campaign_type OWNER TO listmonk;

--
-- Name: content_type; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.content_type AS ENUM (
    'richtext',
    'html',
    'plain',
    'markdown'
);


ALTER TYPE public.content_type OWNER TO listmonk;

--
-- Name: list_optin; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.list_optin AS ENUM (
    'single',
    'double'
);


ALTER TYPE public.list_optin OWNER TO listmonk;

--
-- Name: list_type; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.list_type AS ENUM (
    'public',
    'private',
    'temporary'
);


ALTER TYPE public.list_type OWNER TO listmonk;

--
-- Name: subscriber_status; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.subscriber_status AS ENUM (
    'enabled',
    'disabled',
    'blocklisted'
);


ALTER TYPE public.subscriber_status OWNER TO listmonk;

--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.subscription_status AS ENUM (
    'unconfirmed',
    'confirmed',
    'unsubscribed'
);


ALTER TYPE public.subscription_status OWNER TO listmonk;

--
-- Name: template_type; Type: TYPE; Schema: public; Owner: listmonk
--

CREATE TYPE public.template_type AS ENUM (
    'campaign',
    'tx'
);


ALTER TYPE public.template_type OWNER TO listmonk;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bounces; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.bounces (
    id integer NOT NULL,
    subscriber_id integer NOT NULL,
    campaign_id integer,
    type public.bounce_type DEFAULT 'hard'::public.bounce_type NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bounces OWNER TO listmonk;

--
-- Name: bounces_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.bounces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bounces_id_seq OWNER TO listmonk;

--
-- Name: bounces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.bounces_id_seq OWNED BY public.bounces.id;


--
-- Name: campaign_lists; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.campaign_lists (
    id bigint NOT NULL,
    campaign_id integer NOT NULL,
    list_id integer,
    list_name text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.campaign_lists OWNER TO listmonk;

--
-- Name: campaign_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.campaign_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaign_lists_id_seq OWNER TO listmonk;

--
-- Name: campaign_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.campaign_lists_id_seq OWNED BY public.campaign_lists.id;


--
-- Name: campaign_media; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.campaign_media (
    campaign_id integer,
    media_id integer,
    filename text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.campaign_media OWNER TO listmonk;

--
-- Name: campaign_views; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.campaign_views (
    id bigint NOT NULL,
    campaign_id integer NOT NULL,
    subscriber_id integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.campaign_views OWNER TO listmonk;

--
-- Name: campaign_views_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.campaign_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaign_views_id_seq OWNER TO listmonk;

--
-- Name: campaign_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.campaign_views_id_seq OWNED BY public.campaign_views.id;


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.campaigns (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    from_email text NOT NULL,
    body text NOT NULL,
    altbody text,
    content_type public.content_type DEFAULT 'richtext'::public.content_type NOT NULL,
    send_at timestamp with time zone,
    headers jsonb DEFAULT '[]'::jsonb NOT NULL,
    status public.campaign_status DEFAULT 'draft'::public.campaign_status NOT NULL,
    tags character varying(100)[],
    type public.campaign_type DEFAULT 'regular'::public.campaign_type,
    messenger text NOT NULL,
    template_id integer DEFAULT 1,
    to_send integer DEFAULT 0 NOT NULL,
    sent integer DEFAULT 0 NOT NULL,
    max_subscriber_id integer DEFAULT 0 NOT NULL,
    last_subscriber_id integer DEFAULT 0 NOT NULL,
    archive boolean DEFAULT false NOT NULL,
    archive_template_id integer DEFAULT 1,
    archive_meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.campaigns OWNER TO listmonk;

--
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaigns_id_seq OWNER TO listmonk;

--
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.campaigns_id_seq OWNED BY public.campaigns.id;


--
-- Name: link_clicks; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.link_clicks (
    id bigint NOT NULL,
    campaign_id integer,
    link_id integer NOT NULL,
    subscriber_id integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.link_clicks OWNER TO listmonk;

--
-- Name: link_clicks_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.link_clicks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.link_clicks_id_seq OWNER TO listmonk;

--
-- Name: link_clicks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.link_clicks_id_seq OWNED BY public.link_clicks.id;


--
-- Name: links; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.links (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    url text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.links OWNER TO listmonk;

--
-- Name: links_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.links_id_seq OWNER TO listmonk;

--
-- Name: links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.links_id_seq OWNED BY public.links.id;


--
-- Name: lists; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.lists (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    name text NOT NULL,
    type public.list_type NOT NULL,
    optin public.list_optin DEFAULT 'single'::public.list_optin NOT NULL,
    tags character varying(100)[],
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.lists OWNER TO listmonk;

--
-- Name: lists_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.lists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lists_id_seq OWNER TO listmonk;

--
-- Name: lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.lists_id_seq OWNED BY public.lists.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.media (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    provider text DEFAULT ''::text NOT NULL,
    filename text NOT NULL,
    content_type text DEFAULT 'application/octet-stream'::text NOT NULL,
    thumb text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.media OWNER TO listmonk;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_id_seq OWNER TO listmonk;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.settings OWNER TO listmonk;

--
-- Name: subscriber_lists; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.subscriber_lists (
    subscriber_id integer NOT NULL,
    list_id integer NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.subscription_status DEFAULT 'unconfirmed'::public.subscription_status NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.subscriber_lists OWNER TO listmonk;

--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.subscribers (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    attribs jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.subscriber_status DEFAULT 'enabled'::public.subscriber_status NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.subscribers OWNER TO listmonk;

--
-- Name: subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscribers_id_seq OWNER TO listmonk;

--
-- Name: subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.subscribers_id_seq OWNED BY public.subscribers.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: listmonk
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    name text NOT NULL,
    type public.template_type DEFAULT 'campaign'::public.template_type NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.templates OWNER TO listmonk;

--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: listmonk
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.templates_id_seq OWNER TO listmonk;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: listmonk
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: bounces id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.bounces ALTER COLUMN id SET DEFAULT nextval('public.bounces_id_seq'::regclass);


--
-- Name: campaign_lists id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_lists ALTER COLUMN id SET DEFAULT nextval('public.campaign_lists_id_seq'::regclass);


--
-- Name: campaign_views id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_views ALTER COLUMN id SET DEFAULT nextval('public.campaign_views_id_seq'::regclass);


--
-- Name: campaigns id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaigns ALTER COLUMN id SET DEFAULT nextval('public.campaigns_id_seq'::regclass);


--
-- Name: link_clicks id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.link_clicks ALTER COLUMN id SET DEFAULT nextval('public.link_clicks_id_seq'::regclass);


--
-- Name: links id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.links ALTER COLUMN id SET DEFAULT nextval('public.links_id_seq'::regclass);


--
-- Name: lists id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.lists ALTER COLUMN id SET DEFAULT nextval('public.lists_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: subscribers id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscribers ALTER COLUMN id SET DEFAULT nextval('public.subscribers_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Data for Name: bounces; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.bounces (id, subscriber_id, campaign_id, type, source, meta, created_at) FROM stdin;
\.
COPY public.bounces (id, subscriber_id, campaign_id, type, source, meta, created_at) FROM '$$PATH$$/3284.dat';

--
-- Data for Name: campaign_lists; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.campaign_lists (id, campaign_id, list_id, list_name) FROM stdin;
\.
COPY public.campaign_lists (id, campaign_id, list_id, list_name) FROM '$$PATH$$/3286.dat';

--
-- Data for Name: campaign_media; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.campaign_media (campaign_id, media_id, filename) FROM stdin;
\.
COPY public.campaign_media (campaign_id, media_id, filename) FROM '$$PATH$$/3288.dat';

--
-- Data for Name: campaign_views; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.campaign_views (id, campaign_id, subscriber_id, created_at) FROM stdin;
\.
COPY public.campaign_views (id, campaign_id, subscriber_id, created_at) FROM '$$PATH$$/3289.dat';

--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.campaigns (id, uuid, name, subject, from_email, body, altbody, content_type, send_at, headers, status, tags, type, messenger, template_id, to_send, sent, max_subscriber_id, last_subscriber_id, archive, archive_template_id, archive_meta, started_at, created_at, updated_at) FROM stdin;
\.
COPY public.campaigns (id, uuid, name, subject, from_email, body, altbody, content_type, send_at, headers, status, tags, type, messenger, template_id, to_send, sent, max_subscriber_id, last_subscriber_id, archive, archive_template_id, archive_meta, started_at, created_at, updated_at) FROM '$$PATH$$/3291.dat';

--
-- Data for Name: link_clicks; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.link_clicks (id, campaign_id, link_id, subscriber_id, created_at) FROM stdin;
\.
COPY public.link_clicks (id, campaign_id, link_id, subscriber_id, created_at) FROM '$$PATH$$/3293.dat';

--
-- Data for Name: links; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.links (id, uuid, url, created_at) FROM stdin;
\.
COPY public.links (id, uuid, url, created_at) FROM '$$PATH$$/3295.dat';

--
-- Data for Name: lists; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.lists (id, uuid, name, type, optin, tags, description, created_at, updated_at) FROM stdin;
\.
COPY public.lists (id, uuid, name, type, optin, tags, description, created_at, updated_at) FROM '$$PATH$$/3297.dat';

--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.media (id, uuid, provider, filename, content_type, thumb, meta, created_at) FROM stdin;
\.
COPY public.media (id, uuid, provider, filename, content_type, thumb, meta, created_at) FROM '$$PATH$$/3299.dat';

--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.settings (key, value, updated_at) FROM stdin;
\.
COPY public.settings (key, value, updated_at) FROM '$$PATH$$/3301.dat';

--
-- Data for Name: subscriber_lists; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.subscriber_lists (subscriber_id, list_id, meta, status, created_at, updated_at) FROM stdin;
\.
COPY public.subscriber_lists (subscriber_id, list_id, meta, status, created_at, updated_at) FROM '$$PATH$$/3302.dat';

--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.subscribers (id, uuid, email, name, attribs, status, created_at, updated_at) FROM stdin;
\.
COPY public.subscribers (id, uuid, email, name, attribs, status, created_at, updated_at) FROM '$$PATH$$/3303.dat';

--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: listmonk
--

COPY public.templates (id, name, type, subject, body, is_default, created_at, updated_at) FROM stdin;
\.
COPY public.templates (id, name, type, subject, body, is_default, created_at, updated_at) FROM '$$PATH$$/3305.dat';

--
-- Name: bounces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.bounces_id_seq', 1, false);


--
-- Name: campaign_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.campaign_lists_id_seq', 19, true);


--
-- Name: campaign_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.campaign_views_id_seq', 23, true);


--
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.campaigns_id_seq', 7, true);


--
-- Name: link_clicks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.link_clicks_id_seq', 14, true);


--
-- Name: links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.links_id_seq', 6, true);


--
-- Name: lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.lists_id_seq', 5, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.media_id_seq', 1, true);


--
-- Name: subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.subscribers_id_seq', 37, true);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: listmonk
--

SELECT pg_catalog.setval('public.templates_id_seq', 3, true);


--
-- Name: bounces bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.bounces
    ADD CONSTRAINT bounces_pkey PRIMARY KEY (id);


--
-- Name: campaign_lists campaign_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_lists
    ADD CONSTRAINT campaign_lists_pkey PRIMARY KEY (id);


--
-- Name: campaign_views campaign_views_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_views
    ADD CONSTRAINT campaign_views_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_uuid_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_uuid_key UNIQUE (uuid);


--
-- Name: link_clicks link_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_pkey PRIMARY KEY (id);


--
-- Name: links links_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_pkey PRIMARY KEY (id);


--
-- Name: links links_url_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_url_key UNIQUE (url);


--
-- Name: links links_uuid_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_uuid_key UNIQUE (uuid);


--
-- Name: lists lists_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_pkey PRIMARY KEY (id);


--
-- Name: lists lists_uuid_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_uuid_key UNIQUE (uuid);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media media_uuid_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_uuid_key UNIQUE (uuid);


--
-- Name: settings settings_key_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_key_key UNIQUE (key);


--
-- Name: subscriber_lists subscriber_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscriber_lists
    ADD CONSTRAINT subscriber_lists_pkey PRIMARY KEY (subscriber_id, list_id);


--
-- Name: subscribers subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_email_key UNIQUE (email);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_uuid_key; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_uuid_key UNIQUE (uuid);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: campaign_lists_campaign_id_list_id_idx; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE UNIQUE INDEX campaign_lists_campaign_id_list_id_idx ON public.campaign_lists USING btree (campaign_id, list_id);


--
-- Name: idx_bounces_camp_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_bounces_camp_id ON public.bounces USING btree (campaign_id);


--
-- Name: idx_bounces_date; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_bounces_date ON public.bounces USING btree (((timezone('UTC'::text, created_at))::date));


--
-- Name: idx_bounces_source; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_bounces_source ON public.bounces USING btree (source);


--
-- Name: idx_bounces_sub_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_bounces_sub_id ON public.bounces USING btree (subscriber_id);


--
-- Name: idx_camp_lists_camp_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_camp_lists_camp_id ON public.campaign_lists USING btree (campaign_id);


--
-- Name: idx_camp_lists_list_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_camp_lists_list_id ON public.campaign_lists USING btree (list_id);


--
-- Name: idx_camp_media_camp_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_camp_media_camp_id ON public.campaign_media USING btree (campaign_id);


--
-- Name: idx_camp_media_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE UNIQUE INDEX idx_camp_media_id ON public.campaign_media USING btree (campaign_id, media_id);


--
-- Name: idx_clicks_camp_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_clicks_camp_id ON public.link_clicks USING btree (campaign_id);


--
-- Name: idx_clicks_date; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_clicks_date ON public.link_clicks USING btree (((timezone('UTC'::text, created_at))::date));


--
-- Name: idx_clicks_link_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_clicks_link_id ON public.link_clicks USING btree (link_id);


--
-- Name: idx_clicks_sub_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_clicks_sub_id ON public.link_clicks USING btree (subscriber_id);


--
-- Name: idx_settings_key; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_settings_key ON public.settings USING btree (key);


--
-- Name: idx_sub_lists_list_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_sub_lists_list_id ON public.subscriber_lists USING btree (list_id);


--
-- Name: idx_sub_lists_status; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_sub_lists_status ON public.subscriber_lists USING btree (status);


--
-- Name: idx_sub_lists_sub_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_sub_lists_sub_id ON public.subscriber_lists USING btree (subscriber_id);


--
-- Name: idx_subs_email; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE UNIQUE INDEX idx_subs_email ON public.subscribers USING btree (lower(email));


--
-- Name: idx_subs_status; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_subs_status ON public.subscribers USING btree (status);


--
-- Name: idx_views_camp_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_views_camp_id ON public.campaign_views USING btree (campaign_id);


--
-- Name: idx_views_date; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_views_date ON public.campaign_views USING btree (((timezone('UTC'::text, created_at))::date));


--
-- Name: idx_views_subscriber_id; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE INDEX idx_views_subscriber_id ON public.campaign_views USING btree (subscriber_id);


--
-- Name: templates_is_default_idx; Type: INDEX; Schema: public; Owner: listmonk
--

CREATE UNIQUE INDEX templates_is_default_idx ON public.templates USING btree (is_default) WHERE (is_default = true);


--
-- Name: bounces bounces_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.bounces
    ADD CONSTRAINT bounces_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bounces bounces_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.bounces
    ADD CONSTRAINT bounces_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_lists campaign_lists_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_lists
    ADD CONSTRAINT campaign_lists_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_lists campaign_lists_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_lists
    ADD CONSTRAINT campaign_lists_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaign_media campaign_media_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_media
    ADD CONSTRAINT campaign_media_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_media campaign_media_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_media
    ADD CONSTRAINT campaign_media_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaign_views campaign_views_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_views
    ADD CONSTRAINT campaign_views_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campaign_views campaign_views_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaign_views
    ADD CONSTRAINT campaign_views_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaigns campaigns_archive_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_archive_template_id_fkey FOREIGN KEY (archive_template_id) REFERENCES public.templates(id) ON DELETE SET DEFAULT;


--
-- Name: campaigns campaigns_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id) ON DELETE SET DEFAULT;


--
-- Name: link_clicks link_clicks_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: link_clicks link_clicks_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_link_id_fkey FOREIGN KEY (link_id) REFERENCES public.links(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: link_clicks link_clicks_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.link_clicks
    ADD CONSTRAINT link_clicks_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscriber_lists subscriber_lists_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscriber_lists
    ADD CONSTRAINT subscriber_lists_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriber_lists subscriber_lists_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: listmonk
--

ALTER TABLE ONLY public.subscriber_lists
    ADD CONSTRAINT subscriber_lists_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.subscribers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

